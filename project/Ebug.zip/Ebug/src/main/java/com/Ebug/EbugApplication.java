package com.Ebug;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EbugApplication {

	public static void main(String[] args) {
		SpringApplication.run(EbugApplication.class, args);
	}

}
